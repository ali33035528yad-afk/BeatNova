package com.beatnova.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.CompositionLocalProvider

private val Background = Color(0xFF101118)
private val CardColor = Color(0xFF1B1D27)
private val Accent = Color(0xFFFF4F8B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme {
                    Surface(Modifier.fillMaxSize(), color = Background) { BeatNovaApp() }
                }
            }
        }
    }
}

@Composable
private fun BeatNovaApp() {
    var tab by remember { mutableIntStateOf(0) }
    val titles = listOf("BeatNova", "جستجو", "علاقه‌مندی‌ها", "پروفایل")
    Scaffold(
        containerColor = Background,
        topBar = { TopAppBar(title = { Text(titles[tab], fontWeight = FontWeight.Bold) }) },
        bottomBar = {
            NavigationBar(containerColor = CardColor) {
                NavigationBarItem(tab == 0, { tab = 0 }, { Icon(Icons.Default.Home, "خانه") }, label = { Text("خانه") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Icon(Icons.Default.Search, "جستجو") }, label = { Text("جستجو") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Icon(Icons.Default.Favorite, "علاقه‌مندی‌ها") }, label = { Text("علاقه‌مندی‌ها") })
                NavigationBarItem(tab == 3, { tab = 3 }, { Icon(Icons.Default.Person, "پروفایل") }, label = { Text("پروفایل") })
            }
        }
    ) { p ->
        when (tab) {
            0 -> Home(Modifier.padding(p))
            1 -> SearchPage(Modifier.padding(p))
            2 -> Favorites(Modifier.padding(p))
            else -> Profile(Modifier.padding(p))
        }
    }
}

@Composable
private fun Home(modifier: Modifier) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(
            Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF5A189A), Accent))).padding(22.dp)
        ) {
            Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("به دنیای آهنگ‌های ترند خوش آمدید 🎧", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = Color.White)
                    Spacer(Modifier.height(8.dp))
                    Text("موسیقی‌های محبوب امروز را کشف کن.", color = Color.White)
                }
                Button(onClick = {}) {
                    Icon(Icons.Default.PlayArrow, null)
                    Spacer(Modifier.width(6.dp))
                    Text("شروع پخش")
                }
            }
        }
        Title("آهنگ‌های ترند امروز 🔥")
        Song("Espresso", "Sabrina Carpenter")
        Song("Beautiful Things", "Benson Boone")
        Song("Lose Control", "Teddy Swims")
        Song("Flowers", "Miley Cyrus")
        Title("ترندهای شبکه‌های اجتماعی")
        Trend("📸  ترند اینستاگرام")
        Trend("🎵  ترند تیک‌تاک")
        Title("جدیدترین آهنگ‌ها")
        Song("Die For You", "The Weeknd")
        Song("Calm Down", "Rema")
    }
}

@Composable private fun Title(t: String) {
    Text(t, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
}

@Composable private fun Song(title: String, artist: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(CardColor), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(58.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Color(0xFF7B2CBF), Accent))), contentAlignment = Alignment.Center) {
                Text("♪", color = Color.White, style = MaterialTheme.typography.headlineSmall)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, color = Color.White)
                Text(artist, color = Color.LightGray)
            }
            Icon(Icons.Default.PlayArrow, "پخش", tint = Accent)
        }
    }
}

@Composable private fun Trend(t: String) {
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(CardColor), shape = RoundedCornerShape(18.dp)) {
        Text(t, color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(20.dp))
    }
}

@Composable private fun SearchPage(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("جستجوی آهنگ", color = Color.White, style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(CardColor)) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = Accent)
                Spacer(Modifier.width(12.dp))
                Text("نام آهنگ یا خواننده را جستجو کنید", color = Color.LightGray)
            }
        }
    }
}

@Composable private fun Favorites(modifier: Modifier) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("علاقه‌مندی‌ها ❤️")
        Song("Espresso", "Sabrina Carpenter")
        Song("Beautiful Things", "Benson Boone")
        Song("Lose Control", "Teddy Swims")
    }
}

@Composable private fun Profile(modifier: Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Box(Modifier.size(92.dp).clip(RoundedCornerShape(46.dp)).background(Accent), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, null, Modifier.size(54.dp))
        }
        Text("MusicLover", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("عاشق موسیقی ❤️", color = Color.LightGray)
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(CardColor)) {
            Row(Modifier.fillMaxWidth().padding(20.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                Text("12\nلیست‌ها", color = Color.White)
                Text("248\nعلاقه‌مندی‌ها", color = Color.White)
                Text("3.5K\nدنبال‌کننده", color = Color.White)
            }
        }
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(CardColor)) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Settings, null, tint = Accent)
                Spacer(Modifier.width(12.dp))
                Text("تنظیمات برنامه", color = Color.White)
            }
        }
    }
}
