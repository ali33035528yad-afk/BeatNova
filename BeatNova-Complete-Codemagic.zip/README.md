# BeatNova
اپلیکیشن موسیقی فارسی با رابط راست‌به‌چپ.
فایل codemagic.yaml برای ساخت APK دیباگ در Codemagic آماده است.
